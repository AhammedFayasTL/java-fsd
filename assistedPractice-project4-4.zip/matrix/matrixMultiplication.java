package matrix;

public class matrixMultiplication {
	public static void main(String[] args) {
		int row1 = 2, col = 3;
		int row2 = 3, col2 = 2;
		int[][] firstMatrix = { { 8, 2, 4 }, { 7, 3, 0 } };
		int[][] secondMatrix = { { 9, 6 }, { 2, 8 }, { 1, 0 } };
		int[][] product = multiplyMatrices(firstMatrix, secondMatrix, row1, col, col2);
		displayProduct(product);
	}

	public static int[][] multiplyMatrices(int[][] firstMatrix, int[][] secondMatrix, int r1, int c1, int c2) {
		int[][] product = new int[r1][c2];
		for (int i = 0; i < r1; i++) {
			for (int j = 0; j < c2; j++) {
				for (int k = 0; k < c1; k++) {
					product[i][j] += firstMatrix[i][k] * secondMatrix[k][j];
				}
			}
		}
		return product;
	}

	public static void displayProduct(int[][] product) {
		System.out.println("Product of two matrices is: ");
		for (int[] row : product) {
			for (int column : row) {
				System.out.print(column + "    ");
			}
			System.out.println();
		}
	}
}

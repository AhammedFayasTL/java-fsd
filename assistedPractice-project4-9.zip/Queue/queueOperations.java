package Queue;

import java.util.Queue;
import java.util.LinkedList;

public class queueOperations {
	public static void main(String[] args) {
		Queue<String> fruitQueue = new LinkedList<>();
		fruitQueue.add("Apple");
		fruitQueue.add("Banana");
		fruitQueue.add("Orange");
		System.out.println("Queue is : " + fruitQueue);
		fruitQueue.remove();
		System.out.println("After removing Head of Queue : " + fruitQueue);
	}
}
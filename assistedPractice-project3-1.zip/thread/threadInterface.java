package thread;

class thread2 implements Runnable {
	public void run() {
		System.out.println("Thread is created !");
	}
}

public class threadInterface {
	public static void main(String[] args) {
		thread2 obj = new thread2();
		Thread obj1 = new Thread(obj);
		obj1.start();

	}
}

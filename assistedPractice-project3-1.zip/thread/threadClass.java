package thread;

class thread1 extends Thread {
	public void run() {
		System.out.println("Thread is created");
		System.out.println("Thread Id : " + this.getId());
	}
}

public class threadClass {
	public static void main(String[] args) {
		thread1 obj = new thread1();
		obj.start();

	}
}

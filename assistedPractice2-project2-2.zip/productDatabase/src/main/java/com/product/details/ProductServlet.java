package com.product.details;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//int pid = Integer.parseInt(request.getParameter("txtid"));
		String pname = request.getParameter("txtname");
		int quantity = Integer.parseInt(request.getParameter("txtqty"));
		double price = Double.parseDouble(request.getParameter("txtprice"));
		
		PrintWriter out = response.getWriter();
		/*
		 * out.println(rollno); out.println(name); out.println(marks);
		 */

		try {
			// Call Connection Method
			Connection con = DBconnection.getMyConnection();
			// Write sql command
			String str = "Insert into product (pname,quantity,price) values(?,?,?)";
			response.setContentType("text/html");
			PreparedStatement ps = con.prepareStatement(str);
			//ps.setInt(1, pid);
			ps.setString(1, pname);
			ps.setInt(2, quantity);
			ps.setDouble(3, price);
			int ans = ps.executeUpdate();

			if (ans > 0)
				out.println("Record inserted");
			else
				out.println("Record not inserted");
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

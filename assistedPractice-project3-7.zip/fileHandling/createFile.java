package fileHandling;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class createFile {

	public static void createFileUsingFileClass() throws IOException {
		// create file
		File file = new File("C:\\Users\\Ahammed Fayas T L\\Desktop\\simplielearn-java\\new.txt");

		if (file.createNewFile()) {
			System.out.println("File is Created");
		} else {
			System.out.println("File  is already Exist");
		}

		FileWriter writer = new FileWriter(file, false);
		writer.write("Welcometo my world...!");
		writer.close();

	}

	public static void main(String[] args) {
		try {
			createFileUsingFileClass();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

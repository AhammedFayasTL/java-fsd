package fileHandling;
import java.io.*;

public class readFile {

	public static void readFileReaderClass() throws IOException {
		FileReader reader = new FileReader("C:\\Users\\Ahammed Fayas T L\\Desktop\\simplielearn-java\\new.txt");

		int data;

		while ((data = reader.read()) != -1) {

			System.out.print((char) data);
		}

	}

	
	public static void main(String[] args) {

		try {
			readFileReaderClass();
		} catch (IOException e) {
			System.out.println("File not found");
		}
	}

}
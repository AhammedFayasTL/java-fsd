package com.junit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class StandardTest {
	@BeforeAll
	public static void beforeAll() {
		System.out.println("Before all test cases");
	}
    @BeforeEach
	public void beforeEach() {
		System.out.println("Before each test cases");
	}
    @DisplayName("Standard Test")
    @Test
	public void test1() {
		System.out.println("Test1 cases");
	}
    @Test
	public void test2() {
		System.out.println("Test2 cases");
	}
    @AfterEach
	public void afterEach() {
		System.out.println("After each test cases");
	}
    @AfterAll
	public static void afterAll() {
		System.out.println("After all test cases");
	}

}

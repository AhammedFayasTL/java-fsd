package oops;

abstract class car {

	public abstract void carColor();

	public void stop() {
		System.out.println("Stopped!");
	}
}

class swift extends car {
	public void carColor() {

		System.out.println("Swift color : red");
	}
}

public class abstraction {
	public static void main(String[] args) {
		swift ob = new swift();
		ob.carColor();
		ob.stop();
	}
}
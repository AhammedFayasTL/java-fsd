package oops;

public class classObject {
	int x = 5;

	public static void main(String[] args) {
		classObject obj = new classObject();
		System.out.println(obj.x);
	}
}

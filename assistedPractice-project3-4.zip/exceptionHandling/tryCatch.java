package exceptionHandling;

public class tryCatch {

	public static void main(String[] args) {

		try {
			System.out.println(9 / 0);
			throw new ArithmeticException();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		}
		System.out.println("Hello");
	}

}
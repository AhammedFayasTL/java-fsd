package linearSearch;

import java.util.Scanner;

public class linearSearch {

	public static void main(String[] args) {
		int arr[] = { 12, 56, 3, 90, 25, 66 };
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a value to be searched");
		int key = sc.nextInt();
		// search for key
		boolean f = false;
		for (int val : arr) {
			if (val == key) {
				f = true;
				break;
			}

		}

		if (f == true)
			System.out.println("Value is present");

		else
			System.out.println("Value is not present");

	}

}
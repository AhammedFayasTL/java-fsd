package customException;

class InsufficentBalance extends Exception {
	public InsufficentBalance(String str) {
		super(str);
	}
}

public class customExceptionBalance {
	static void check(int bal) throws InsufficentBalance {
		if (bal > 2500) {
			throw new InsufficentBalance("you dont have sufficient balance for retrieve money");
		} else {
			System.out.println("take your money");
		}
	}

	public static void main(String[] args) {
		try {
			check(1000);
		} catch (InsufficentBalance e) {
			e.printStackTrace();
		}
	}
}
package com.example.demo;

@SuppressWarnings("serial")
public class ProductException extends RuntimeException {

}

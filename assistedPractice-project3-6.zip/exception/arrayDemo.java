package exception;

public class arrayDemo  {
	static void getInfo()throws ArithmeticException, ArrayIndexOutOfBoundsException{
		System.out.println(5/2);
		int arr[]={7};
		System.out.println(arr[2]);
	}
	public static void main(String[] args) {
	
	try{	
	getInfo();
	}
	catch(ArithmeticException|ArrayIndexOutOfBoundsException e){
		e.printStackTrace();
	}
		System.out.println("Completed");
}}
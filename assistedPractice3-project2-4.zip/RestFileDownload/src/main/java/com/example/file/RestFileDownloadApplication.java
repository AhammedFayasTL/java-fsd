package com.example.file;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestFileDownloadApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestFileDownloadApplication.class, args);
	}

}

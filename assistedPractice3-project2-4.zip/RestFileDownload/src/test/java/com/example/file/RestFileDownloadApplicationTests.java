package com.example.file;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestFileDownloadApplicationTests {

	@Test
	void contextLoads() {
	}

}

package binarySearch;
import java.util.Scanner;

public class binarySearch {
	public static void main(String[] args) {
		int arr[] = { 2, 4, 9, 12, 20, 24 };
		System.out.println("Enter a Key value to be Search : ");
		Scanner sc = new Scanner(System.in);
		int key = sc.nextInt();

		int arrLength = arr.length;

		try {
			bSearch(arr, 0, key, arrLength);
		} catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
			System.out.println("Error: " + e);
		}

	}

	private static void bSearch(int[] arr, int lb, int key, int ub) {

		int midValue = (lb + ub) / 2;

		while (lb <= ub) {

			if (arr[midValue] < key) {
				lb = midValue + 1;
			} else if (arr[midValue] == key) {
				System.out.println("Element found at index: " + midValue);
				break;
			} else {
				ub = midValue - 1;
			}
			midValue = (lb + ub) / 2;
		}
		if (lb > ub) {
			System.out.println("Element Not Found");
		}

	}
}

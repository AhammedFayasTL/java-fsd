package beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class product {

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private int pid;
		@Column
		private String pname;
		@Column
		private int quantity;
		@Column
        private int price;

		public int getId() {
			return pid;
		}

		public void setId(int pid) {
			this.pid = pid;
		}
		
		
		public String getName() {
			return pname;
		}

		public void setName(String pname) {
			this.pname= pname;
		}

		public int getQuantity() {
			return quantity;
		}

		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public int getPrice() {
			return price;
		}

		public void setPrice(int price) {
			this.price = price;
		}
}

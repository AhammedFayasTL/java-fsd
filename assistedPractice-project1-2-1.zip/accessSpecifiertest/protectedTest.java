package accessSpecifiertest;

import accessSpecifiers.*;

public class protectedTest extends protectedAccessSpecifier {

	public static void main(String[] args) {
		protectedTest obj = new protectedTest();
		obj.display();
	}

}

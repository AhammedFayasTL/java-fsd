package accessSpecifiertest;

import accessSpecifiers.*;

public class publicTest {

	public static void main(String[] args) {

		publicAccessSpecifier obj = new publicAccessSpecifier();
		obj.display();

	}
}

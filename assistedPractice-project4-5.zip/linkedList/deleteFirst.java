package linkedList;

public class deleteFirst {

	Node head;

	static class Node {
		int data;
		Node next;

		Node(int d) {
			data = d;
			next = null;
		}
	}

	// method to create a new node
	public static deleteFirst insert(deleteFirst list, int data) {

		Node new_node = new Node(data);
		new_node.next = null;

		if (list.head == null) {
			list.head = new_node;
		} else {
			Node last = list.head;
			while (last.next != null) {
				last = last.next;
			}
			last.next = new_node;
		}

		return list;
	}

	public static void printList(deleteFirst list) {

		Node currNode = list.head;
		System.out.print("LinkedList: ");

		while (currNode != null) {
			// print the data of current node
			System.out.print(currNode.data + " ");

			// go to the next node

			currNode = currNode.next;
		}

		System.out.println();
	}

	public static deleteFirst deleteByKey(deleteFirst list, int key) {
		Node currNode = list.head, prev = null;
		// to delete a first node
		if (currNode != null && currNode.data == key) {
			list.head = currNode.next;
			System.out.println(key + " found and deleted");
			return list;
		}

		while (currNode != null && currNode.data != key) {
			prev = currNode;
			currNode = currNode.next;
		}
		if (currNode != null) {
			prev.next = currNode.next;
			System.out.println(key + " found and deleted");
		}

		if (currNode == null) {
			System.out.println(key + " not found");
		}
		return list;
	}

	public static void main(String[] args) {
		// create a list and insert values
		deleteFirst list = new deleteFirst();
		list = insert(list, 23);
		list = insert(list, 29);
		list = insert(list, 45);
		list = insert(list, 90);
		list = insert(list, 74);
		list = insert(list, 32);
		list = insert(list, 2);
		list = insert(list, 56);
		// call printList method
		printList(list);

		// delete node

		// deleting Head
		deleteByKey(list, 32);
		// print linked list
		printList(list);

	}

}
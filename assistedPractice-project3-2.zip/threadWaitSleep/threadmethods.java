package threadWaitSleep;

public class threadmethods {
	private static Object fix = new Object();

	public static void main(String args[]) throws InterruptedException {
		Thread.sleep(1000);
		System.out.println("Thread '" + Thread.currentThread().getName() + "' is woken after sleeping for 3 second");
		synchronized (fix) {
			fix.wait(3000);
			System.out.println("Object '" + fix + "' is woken after" + " waiting for 3 second");
		}
	}
}

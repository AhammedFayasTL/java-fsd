package com.calc;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	void test() {
		Calculator obj = new Calculator();
		assertEquals(10, obj.addition(5, 6));
	}

}

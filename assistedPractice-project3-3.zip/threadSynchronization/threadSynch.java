package threadSynchronization;

class firstTable {

	void printFinal(int n, Thread t) {

		synchronized (this) {
			System.out.println("Thread id=" + t.getId());
			for (int i = 1; i <= 5; i++) {
				System.out.println(n * i);
				try {
					Thread.sleep(400);
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		} // end block

		System.out.println("Square of "+ (n )+ " =" +  (n * n) + " id=" + t.getId());
	}// end of the method
}

class thread1 extends Thread {
	firstTable t;

	thread1(firstTable t) {
		this.t = t;
	}

	public void run() {
		t.printFinal(5, this);
	}

}

class thread2 extends Thread {
	firstTable t;

	thread2(firstTable t) {
		this.t = t;
	}

	public void run() {
		t.printFinal(100, this);
	}
}

public class threadSynch {
	public static void main(String args[]) {
		firstTable obj = new firstTable();// only one object
		thread1 t1 = new thread1(obj);
		thread2 t2 = new thread2(obj);
		t1.start();
		t2.start();
	}

}
package com.calc;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
class AssertThrow {

	@Test
	void test() {
		Calculator obj = new Calculator();
		assertEquals(11, obj.addition(5, 6));
	}

	@Test
	void test1() {

		assertThrows(ArithmeticException.class, () -> {
			throw new RuntimeException();
		});

	}

}

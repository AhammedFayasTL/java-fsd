package arrayRotate;
import java.util.*;
import java.util.Scanner;
public class arrayRotation {

    // Function to right-rotate an array by one position
    public static void rightRotateByOne(int[] A)
    {
        int last = A[A.length - 1];
        for (int i = A.length - 2; i >= 0; i--) {
            A[i + 1] = A[i];
        }
 
        A[0] = last;
    }
 
    // Function to right-rotate an array by `k` positions
    public static void rightRotate(int[] A, int k)
    {
        // base case: invalid input
        if (k < 0 || k >= A.length) {
            return;
        }
 
        for (int i = 0; i < k; i++) {
            rightRotateByOne(A);
        }
    }
 
    public static void main(String[] args)
    {
        int arr[] = new int[6];
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the no of array elements : ");
        int a = sc.nextInt();
        System.out.println("Enter array elemtnts : ");
        for(int i=0;i<a;i++) {
        arr[i]=sc.nextInt();
        }
        int k = 5;
 
        rightRotate(arr, k);
 
        System.out.println(Arrays.toString(arr));
    }
}